# Dark Sonic WebView + Android Screen Pinning / Lock Task

Project Android Studio yang membungkus HTML Dark Sonic ke dalam WebView.

## Cara build
1. Buka folder `DarkSonicWebView` dengan Android Studio.
2. Tunggu Gradle Sync selesai.
3. Jalankan di perangkat Android atau emulator.
4. Build > Build APK(s).

## Screen Pinning vs Lock Task
Aplikasi memanggil `Activity.startLockTask()` melalui JavaScript bridge.

- Jika aplikasi BELUM diizinkan oleh Device Policy Manager, Android akan masuk ke **Screen Pinning** dan menampilkan dialog/konfirmasi sistem.
- Jika aplikasi sudah menjadi package yang diizinkan oleh Device Owner/Profile Owner, Android dapat masuk ke **Lock Task Mode** langsung.

Ini adalah mekanisme Android resmi; HTML/JavaScript sendiri tidak dapat mengunci tombol Home/Recent secara penuh.

## Mengaktifkan Lock Task sebagai Device Owner (pengujian)
Gunakan perangkat uji yang siap diprovisioning. Setelah perangkat sesuai untuk provisioning, dari komputer dengan ADB:

`PIN akses HTML: 131204`\n\n`adb shell dpm set-device-owner com.tesaia.darksonic/.MyDeviceAdminReceiver`

Setelah menjadi Device Owner, aplikasi perlu mengizinkan package-nya untuk Lock Task. Implementasi produksi sebaiknya mengatur allowlist menggunakan DevicePolicyManager dari DPC/Device Owner.

Jangan menjalankan provisioning Device Owner pada perangkat utama tanpa memahami konsekuensinya: provisioning dapat membutuhkan perangkat yang belum diprovisioning dan dapat mengubah kebijakan perangkat.

## Catatan keamanan
JavaScript bridge hanya dipakai untuk file HTML lokal milik aplikasi. Jangan mengizinkan halaman web tak tepercaya mengakses interface `Android`.
