# Build Dark Sonic APK dari HP (tanpa Android Studio)

## Pilihan paling mudah: GitHub Actions
Project ini sudah dilengkapi workflow `.github/workflows/android.yml`.

1. Buat repository GitHub baru dari browser HP.
2. Upload seluruh isi ZIP project ini ke repository.
3. Buka tab **Actions**.
4. Pilih workflow **Build Dark Sonic APK**.
5. Tekan **Run workflow**.
6. Setelah selesai, buka hasil run dan bagian **Artifacts**.
7. Download `DarkSonic-debug-apk`.
8. Extract ZIP artifact dan install APK di HP.

Tidak perlu Android Studio di HP.

## Catatan
- Build yang dibuat adalah debug APK.
- Fitur Screen Pinning/Lock Task tetap mengikuti aturan Android.
- `131204` adalah PIN yang digunakan oleh halaman HTML untuk membuka kunci UI.
- Lock Task native tidak dapat dipaksa aktif hanya oleh HTML; perangkat/administrasi Android harus mengizinkannya.

## Jika GitHub tidak nyaman
File `.gitlab-ci.yml` juga disediakan sebagai alternatif cloud CI.
