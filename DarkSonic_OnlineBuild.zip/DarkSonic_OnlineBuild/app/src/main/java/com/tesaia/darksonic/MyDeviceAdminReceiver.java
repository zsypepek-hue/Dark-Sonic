package com.tesaia.darksonic;

import android.app.admin.DeviceAdminReceiver;

public class MyDeviceAdminReceiver extends DeviceAdminReceiver {
}
