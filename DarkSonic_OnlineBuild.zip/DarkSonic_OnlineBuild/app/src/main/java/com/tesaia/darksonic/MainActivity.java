package com.tesaia.darksonic;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private DevicePolicyManager dpm;
    private ComponentName admin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webview);

        dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        admin = new ComponentName(this, MyDeviceAdminReceiver.class);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");

        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void startScreenPin() {
            runOnUiThread(() -> {
                try {
                    // Jika aplikasi sudah di-allowlist oleh Device Owner,
                    // Android masuk Lock Task Mode langsung.
                    // Jika belum, Android akan menggunakan Screen Pinning
                    // dan menampilkan konfirmasi sistem.
                    startLockTask();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "Gagal mengaktifkan pinning: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void stopScreenPin() {
            runOnUiThread(() -> {
                try {
                    stopLockTask();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "Gagal menghentikan lock task.",
                            Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public boolean isLockTaskPermitted() {
            return dpm != null && dpm.isLockTaskPermitted(getPackageName());
        }
    }
}
